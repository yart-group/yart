#include "outputgadget.h"
