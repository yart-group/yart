#ifndef FLASH_H
#define FLASH_H

#include "device.h"

class Flash : public Device
{
  public:
    Flash();
};

#endif // FLASH_H
