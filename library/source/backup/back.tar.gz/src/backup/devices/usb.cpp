#include "usb.h"

Usb::Usb()
{

}
