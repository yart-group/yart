#ifndef USB_H
#define USB_H

#include "device.h"

class Usb : public Device
{
  public:
    Usb();
};

#endif // USB_H
