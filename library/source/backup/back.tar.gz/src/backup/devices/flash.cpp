#include "flash.h"

Flash::Flash()
{

}
