#ifndef CABLE_H
#define CABLE_H

#include "iogadget.h"

class Cable : public IOGadget
{
  public:
};

#endif // CABLE_H
