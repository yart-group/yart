#ifndef SENSOR_H
#define SENSOR_H

#include "inputgadget.h"

class Sensor : public InputGadget
{
  public:
};

#endif // SENSOR_H
