#ifndef BATTERY_H
#define BATTERY_H

#include "iogadget.h"

class Battery : public InputGadget
{
  public:
};

#endif // BATTERY_H
